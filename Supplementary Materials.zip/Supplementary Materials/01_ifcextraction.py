import ifcopenshell
import pandas as pd
import json

# Define the mapping from IFC classes to BI-KG Semantic Schema categories
SEMANTIC_MAPPING = {
    # Case Building (Global Context Node)
    'IfcProject': 'Case Building',
    'IfcBuilding': 'Case Building',
    
    # Passive Envelope
    'IfcWall': 'Passive Envelope',
    'IfcWindow': 'Passive Envelope',
    'IfcDoor': 'Passive Envelope',
    'IfcRoof': 'Passive Envelope',
    'IfcSlab': 'Passive Envelope',
    
    # Thermal Space
    'IfcSpace': 'Thermal Space',
    'IfcTransportElement': 'Thermal Space',
    
    # Active Equipment
    'IfcUnitaryEquipment': 'Active Equipment',
    'IfcHeatExchanger': 'Active Equipment',
    'IfcTransformer': 'Active Equipment',
    'IfcLightFixture': 'Active Equipment',
    
    # Energy Generator
    'IfcSolarDevice': 'Energy Generator',
    'IfcPump': 'Energy Generator',
    'IfcBoiler': 'Energy Generator',
    'IfcSensor': 'Energy Generator'
}

def get_properties_and_quantities(element):
    """Extract properties (Pset) and quantities (Qto) from an IFC element."""
    props = {}
    if hasattr(element, "IsDefinedBy"):
        for definition in element.IsDefinedBy:
            if definition.is_a('IfcRelDefinesByProperties'):
                property_set = definition.RelatingPropertyDefinition
                
                # Handle Property Sets (Pset)
                if property_set.is_a('IfcPropertySet'):
                    pset_name = property_set.Name
                    props[pset_name] = {}
                    for prop in property_set.HasProperties:
                        if prop.is_a('IfcPropertySingleValue') and prop.NominalValue:
                            props[pset_name][prop.Name] = prop.NominalValue.wrappedValue
                            
                # Handle Quantity Sets (Qto)
                elif property_set.is_a('IfcElementQuantity'):
                    qto_name = property_set.Name
                    props[qto_name] = {}
                    for quantity in property_set.Quantities:
                        for attr in ['LengthValue', 'AreaValue', 'VolumeValue', 'WeightValue']:
                            if hasattr(quantity, attr):
                                props[qto_name][quantity.Name] = getattr(quantity, attr)
                                break
    return props

def inject_operational_data(global_id, semantic_type):
    """
    Simulate the injection of operational data (e.g., IEQ records, utility bills) 
    from Building Management Systems (BMS) into specific nodes.
    """
    op_data = {}
    if semantic_type == 'Thermal Space':
        op_data['IEQ_Record'] = {"avg_temp": 24.5, "avg_humidity": 55.0, "CO2_ppm": 420}
    elif semantic_type == 'Case Building':
        op_data['Utility_Bill'] = {"annual_kwh": 120000, "energy_cost_usd": 15000}
    return op_data

def extract_nodes(ifc_file):
    """Extract all mapped entities as BI-KG nodes and inject operational data."""
    nodes = []
    
    for ifc_class, semantic_type in SEMANTIC_MAPPING.items():
        elements = ifc_file.by_type(ifc_class)
        for el in elements:
            base_props = get_properties_and_quantities(el)
            # Inject historical operational records
            base_props['OperationalData'] = inject_operational_data(el.GlobalId, semantic_type)
            
            node_data = {
                'GlobalId': el.GlobalId,
                'Name': el.Name if el.Name else "Unnamed",
                'IfcType': ifc_class,
                'SemanticType': semantic_type,
                'Properties': base_props
            }
            nodes.append(node_data)
            
    # Inject "Outdoor" as a Thermal Space to anchor the building to its external environment
    outdoor_node = {
        'GlobalId': 'OUTDOOR_ANCHOR',
        'Name': 'Outdoor',
        'IfcType': 'VirtualNode',
        'SemanticType': 'Thermal Space',
        'Properties': {
            'Description': 'Virtual thermal space for external boundary reasoning',
            'OperationalData': {'climate_zone': 'Hot Summer Cold Winter (Nanjing)'}
        }
    }
    nodes.append(outdoor_node)
    
    return nodes

def extract_semantic_triples(ifc_file, extracted_nodes):
    """Extract spatial and semantic relationships to form BI-KG triples."""
    triples = []
    
    # 1. Case Building -> Contains -> Thermal Space
    projects = ifc_file.by_type('IfcProject')
    spaces = ifc_file.by_type('IfcSpace')
    if projects:
        project_id = projects[0].GlobalId
        for space in spaces:
            triples.append((project_id, 'Contains', space.GlobalId))
        # Case building contains the outdoor anchor logically for context
        triples.append((project_id, 'Contains', 'OUTDOOR_ANCHOR'))

    # 2. Passive Envelope -> Bounds -> Thermal Space
    for rel in ifc_file.by_type('IfcRelSpaceBoundary'):
        space = rel.RelatingSpace
        element = rel.RelatedBuildingElement
        if space and element:
            sem_type = SEMANTIC_MAPPING.get(element.is_a())
            if sem_type == 'Passive Envelope':
                triples.append((element.GlobalId, 'Bounds', space.GlobalId))
                # Logic for checking external bounding can be added here to link to OUTDOOR_ANCHOR

    # 3. Active Equipment -> Serves -> Thermal Space
    for rel in ifc_file.by_type('IfcRelContainedInSpatialStructure'):
        space = rel.RelatingStructure
        if space and space.is_a('IfcSpace'):
            for element in rel.RelatedElements:
                sem_type = SEMANTIC_MAPPING.get(element.is_a())
                if sem_type == 'Active Equipment':
                    triples.append((element.GlobalId, 'Serves', space.GlobalId))

    # 4. Energy Generator -> Powers -> Active Equipment
    # Using IfcRelConnectsElements or IfcRelFlow as a proxy for power distribution
    for rel in ifc_file.by_type('IfcRelConnectsElements'):
        elem1 = rel.RelatingElement
        elem2 = rel.RelatedElement
        if elem1 and elem2:
            sem1 = SEMANTIC_MAPPING.get(elem1.is_a())
            sem2 = SEMANTIC_MAPPING.get(elem2.is_a())
            if sem1 == 'Energy Generator' and sem2 == 'Active Equipment':
                triples.append((elem1.GlobalId, 'Powers', elem2.GlobalId))

    return triples

def main(ifc_path, output_nodes_json, output_triples_csv):
    print(f"Loading IFC file: {ifc_path}")
    ifc_file = ifcopenshell.open(ifc_path)
    
    print("Extracting BI-KG nodes...")
    nodes = extract_nodes(ifc_file)
    with open(output_nodes_json, 'w', encoding='utf-8') as f:
        json.dump(nodes, f, indent=4, ensure_ascii=False)
        
    print("Extracting BI-KG semantic triples...")
    triples = extract_semantic_triples(ifc_file, nodes)
    
    triples_df = pd.DataFrame(triples, columns=['Head', 'Relation', 'Tail'])
    triples_df.drop_duplicates(inplace=True)
    triples_df.to_csv(output_triples_csv, index=False)
    
    print(f"Extraction complete. Generated {len(nodes)} nodes and {len(triples_df)} semantic triples.")

if __name__ == "__main__":
    ifc_file_path = "case_badminton_hall.ifc" 
    main(ifc_file_path, "bikg_nodes.json", "bikg_triples.csv")