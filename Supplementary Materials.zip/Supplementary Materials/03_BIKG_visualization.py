import json
from pyvis.network import Network

def visualize_bikg(json_graph_path, output_html):
    print(f"Loading graph data from {json_graph_path}...")
    with open(json_graph_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    net = Network(height="850px", width="100%", bgcolor="#ffffff", font_color="black", directed=True)

    # Define color scheme explicitly matching Figure 5(a) of the manuscript
    COLOR_MAP = {
        "Case Building": "#000000",      # Black
        "Thermal Space": "#8ECA5D",      # Green
        "Passive Envelope": "#F8766D",   # Red/Coral
        "Active Equipment": "#9BA2FF",   # Light Blue / Periwinkle
        "Energy Generator": "#F5B041"    # Orange (Placeholder for extensions)
    }

    SIZE_MAP = {
        "Case Building": 40,
        "Thermal Space": 30,
        "Passive Envelope": 15,
        "Active Equipment": 15,
        "Energy Generator": 15
    }

    print("Adding nodes to visualization...")
    for node in data['nodes']:
        node_id = node['id']
        semantic_type = node['type']
        ifc_type = node['properties'].get('ifc_type', '')
        
        color = COLOR_MAP.get(semantic_type, "#CCCCCC")
        size = SIZE_MAP.get(semantic_type, 15)
        
        hover_text = f"<b>Semantic Type:</b> {semantic_type}<br>"
        hover_text += f"<b>IFC Entity:</b> {ifc_type}<br>"
        hover_text += f"<b>GlobalId:</b> {node_id}"
        
        net.add_node(
            node_id,
            label=semantic_type if semantic_type in ["Case Building", "Thermal Space"] else "",
            color=color,
            title=hover_text,
            shape="dot",
            size=size
        )

    print("Adding edges to visualization...")
    for edge in data['edges']:
        net.add_edge(
            edge['source'], 
            edge['target'], 
            title=edge['type'], 
            color="#A0A0A0", 
            arrows="to",
            width=1.5 if edge['type'] == 'Contains' else 1.0
        )

    net.set_options("""
    {
      "physics": {
        "forceAtlas2Based": {
          "gravitationalConstant": -150,
          "centralGravity": 0.01,
          "springLength": 100,
          "springConstant": 0.08,
          "damping": 0.4,
          "avoidOverlap": 0
        },
        "maxVelocity": 50,
        "minVelocity": 0.1,
        "solver": "forceAtlas2Based",
        "timestep": 0.5
      }
    }
    """)

    net.show(output_html, notebook=False)
    print(f"Visualization successfully saved to {output_html}")

if __name__ == "__main__":
    visualize_bikg("bikg_final.json", "bikg_visualization.html")