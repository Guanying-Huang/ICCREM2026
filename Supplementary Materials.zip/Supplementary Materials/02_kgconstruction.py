import json
import pandas as pd
import networkx as nx

class BuildingInformationKnowledgeGraph:
    def __init__(self):
        self.graph = nx.DiGraph()
        
    def build_from_extracted_data(self, nodes_file, triples_file):
        with open(nodes_file, 'r', encoding='utf-8') as f:
            nodes_data = json.load(f)
            
        for node in nodes_data:
            node_id = node['GlobalId']
            flat_props = {
                'name': node['Name'],
                'ifc_type': node['IfcType'],
                'semantic_type': node['SemanticType'],
                'raw_properties': json.dumps(node['Properties'], ensure_ascii=False)
            }
            self.graph.add_node(node_id, **flat_props)
            
        triples_df = pd.read_csv(triples_file)
        for _, row in triples_df.iterrows():
            head = row['Head']
            tail = row['Tail']
            rel_type = row['Relation']
            
            if self.graph.has_node(head) and self.graph.has_node(tail):
                self.graph.add_edge(head, tail, type=rel_type)

    def export_to_json(self, output_file):
        graph_data = {'nodes': [], 'edges': []}
        
        for node_id, data in self.graph.nodes(data=True):
            graph_data['nodes'].append({
                'id': node_id,
                'type': data.get('semantic_type', 'Unknown'),
                'label': data.get('name', node_id),
                'properties': {
                    'ifc_type': data.get('ifc_type'),
                    'raw_properties': data.get('raw_properties')
                }
            })
            
        for head, tail, data in self.graph.edges(data=True):
            graph_data['edges'].append({
                'source': head,
                'target': tail,
                'type': data.get('type', 'related_to')
            })
            
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(graph_data, f, indent=4, ensure_ascii=False)
            
        print(f"BI-KG exported to {output_file} with {len(self.graph.nodes())} nodes and {len(self.graph.edges())} triples.")

if __name__ == "__main__":
    kg = BuildingInformationKnowledgeGraph()
    print("Building BI-KG from extracted data...")
    kg.build_from_extracted_data("bikg_nodes.json", "bikg_triples.csv")
    kg.export_to_json("bikg_final.json")